export const CHECKOUT_LOADING = 'checkout/loading'
export const CHECKOUT_ERROR = 'checkout/error'

export const GET_CHECKOUT_SUCCESS = 'get/checkout/success'
export const UPDATE_CHECKOUT_SUCCESS = 'update/checkout/success'
