


export const AUTH_REQUEST = "auth/request";
export const AUTH_ERROR = "auth/error";

export const AUTH_GET_USERS_SUCCESS = "auth/success";

export const AUTH_GET_SINGLE_USER_SUCCESS = "auth/getSingleUserSuccess";

export const Auth_POST_SINGLE_USER_SUCCESS  = "auth/postSingleUserSuccess";