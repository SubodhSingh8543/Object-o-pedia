export const CART_LOADING = 'cart/loading'
export const CART_ERROR = 'cart/error'

export const GET_CART_SUCCESS = 'get/cart/success'
export const DELETE_CART_SUCCESS = 'delete/cart/success'
export const UPDATE_CART_SUCCESS = 'update/cart/success'
