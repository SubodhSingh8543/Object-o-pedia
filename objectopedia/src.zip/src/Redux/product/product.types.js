

export const PRODUCT_REQUEST = "products/request";


export const PRODUCT_ERROR = "products/error";

export const GET_PRODUCT_SUCCESS = "getProducts/success"

export const HANDLE_PAGE_CHANGE = "HANDLE_PAGE_CHANGE";

export const TOGGLE_LIKE = "TOGGLE_LIKE";