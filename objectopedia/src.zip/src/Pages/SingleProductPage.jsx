

const SingleProductPage = () => {

    return(
        <div>
            SingleProductPage
        </div>
    )
}

export default SingleProductPage;